console.log("Script Working")

let dom = document.getElementsByClassName('L3eUgb')
let randomColor = Math.floor(Math.random()*16777215).toString(16);

document.getElementsByClassName("L3eUgb")[0].style.backgroundColor="#" + randomColor;

dom[0].children[2].children[2].children[0].children[0].children[5].children[0].children[0].value = "the text is changed"
dom[0].children[2].children[2].children[0].children[0].children[5].children[0].children[1].addEventListener("click", eventFunction) 

function eventFunction(){
    alert('clicked')
}